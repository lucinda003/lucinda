from django.contrib import admin
from .models import Record
# Register your models here.

admin.site.register(Record)